package package1;

public class Main
{
	
	    public static void main(String[] args) {
	BankAccount userAccount = new BankAccount(1000.0); 
	        Atm atm = new Atm(userAccount);
	        atm.run();
	    }
	}
